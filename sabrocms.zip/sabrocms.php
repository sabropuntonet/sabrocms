<?php
$estescript = "sabrocms.php";
$apilink = "https://sabro.net/api/sabrocms/sabrocmsapi.php";
$accionpost = isset($_POST['accionpost']) ? $_POST['accionpost'] : '';
if ($accionpost == 'setcms') {
if (!file_exists("sabrocms.cgi")) {
$file = fopen("sabrocms.cgi", "w+");
if ($file) {
fwrite($file, "");
fclose($file);
}
}
$setusr = isset($_POST['setusr']) ? trim($_POST['setusr']) : '';
$setpsw = isset($_POST['setpsw']) ? trim($_POST['setpsw']) : '';
$setapi = isset($_POST['setapi']) ? trim($_POST['setapi']) : '';
$setlg  = isset($_POST['lg']) ? $_POST['lg'] : 'es';
if (
($setusr == '') ||
(strlen($setusr) > 20) ||
(strpos($setusr, ' ') !== false)
) {
echo "
<br><br><br>
<font face=arial size=3 color=#000000>
<div align=center>
ERROR:<br><br>
The desired user is incorrect, it must be a text of less than 20 letters and without spaces.
<br><br>
(El user deseado es incorrecto, debe ser un texto menor de 20 letras y sin espacios.)
</div>
</font>";
exit;
}
if (
($setpsw == '') ||
(strlen($setpsw) > 20) ||
(strpos($setpsw, ' ') !== false)
) {
echo "
<br><br><br>
<font face=arial size=3 color=#000000>
<div align=center>
ERROR:<br><br>
The desired password is incorrect, it must be a text of less than 20 letters and without spaces.
<br><br>
(El password deseado es incorrecto, debe ser un texto menor de 20 letras y sin espacios.)
</div>
</font>";
exit;
}
$esto = trim(curle(
$apilink .
"?api=" . urlencode($setapi) .
"&accion=chk"
));
if (
($setapi == '') ||
(strlen($setapi) < 20) ||
(strpos($setapi, ' ') !== false)
) {
echo "
<br><br><br>
<font face=arial size=3 color=#000000>
<div align=center>
ERROR:<br><br>
The API Key entered:<br><br>
<b>" . htmlspecialchars($setapi) . "</b>
<br><br>
Is not a Valid API Key!
<br><br>
To obtain a valid API Key, visit:
<br><br>
<a href='https://www.sabro.net/sabrocmsen.htm' target='_blank'>
www.sabro.net/sabrocmsen.htm
</a>
<br><br>
<a href='" . $estescript . "'>[ GO BACK ]</a>
<br><br>
<hr>
<br><br>
La Clave API ingresada:
<br><br>
<b>" . htmlspecialchars($setapi) . "</b>
<br><br>
No es una Clave API Correcta!
<br><br>
Para obtener una Clave API valida, visite:
<br><br>
<a href='https://www.sabro.net/sabrocms.htm' target='_blank'>
www.sabro.net/sabrocms.htm
</a>
<br><br>
<a href='" . $estescript . "'>[ REGRESAR ]</a>
</div>
</font>";
exit;
}
if ($esto !== '0') {
echo "
<br><br><br>
<font face=arial size=3 color=#000000>
<div align=center>
ERROR:<br><br>
The API Key entered:
<br><br>
<b>" . htmlspecialchars($setapi) . "</b>
<br><br>
Is not a Valid API Key!
<br><br>
API validation response:
<b>" . htmlspecialchars($esto) . "</b>
<br><br>
To obtain a valid API Key, visit:
<br><br>
<a href='https://www.sabro.net/sabrocmsen.htm' target='_blank'>
www.sabro.net/sabrocmsen.htm
</a>
<br><br>
<a href='" . $estescript . "'>[ GO BACK ]</a>
<br><br>
<hr>
<br><br>
La Clave API ingresada:
<br><br>
<b>" . htmlspecialchars($setapi) . "</b>
<br><br>
No es una Clave API Correcta!
<br><br>
Código recibido del servidor:
<b>" . htmlspecialchars($esto) . "</b>
<br><br>
Para obtener una Clave API valida, visite:
<br><br>
<a href='https://www.sabro.net/sabrocms.htm' target='_blank'>
www.sabro.net/sabrocms.htm
</a>
<br><br>
<a href='" . $estescript . "'>[ REGRESAR ]</a>
</div>
</font>";
exit;
}
if (
($esto != '') &&
($esto !== '0') &&
(strpos($esto, '/') !== false)
) {
echo "
<br><br><br>
<font face=arial size=3 color=#000000>
<div align=center>
ERROR:<br><br>
The API Key entered:
<br><br>
<b>" . htmlspecialchars($setapi) . "</b>
<br><br>
Expired on: " . htmlspecialchars($esto) . " (day/month/year)
<br><br>
To continue using SabroCMS you must purchase a new payment API Key,
which you can purchase at this link:
<br><br>
<a href='https://www.sabro.net/sabrocmsen.htm' target='_blank'>
www.sabro.net/sabrocmsen.htm
</a>
<br><br>
<a href='" . $estescript . "'>[ GO BACK ]</a>
<br><br>
<hr>
<br><br>
La Clave API ingresada:
<br><br>
<b>" . htmlspecialchars($setapi) . "</b>
<br><br>
Caducó el: " . htmlspecialchars($esto) . " (dia/mes/año)
<br><br>
Para seguir usando SabroCMS debe adquirir una nueva Clave API de pago.
<br><br>
<a href='https://www.sabro.net/sabrocms.htm' target='_blank'>
www.sabro.net/sabrocms.htm
</a>
<br><br>
<a href='" . $estescript . "'>[ GO BACK / REGRESAR ]</a>
</div>
</font>";
exit;
}
if (strpos($esto, '/') !== false) {
echo "
<br><br><br>
<font face=arial size=3 color=#000000>
<div align=center>
ERROR:<br><br>
The API Key entered:
<br><br>
<b>" . htmlspecialchars($setapi) . "</b>
<br><br>
Expired on: " . htmlspecialchars($esto) . " (day/month/year)
<br><br>
To continue using SabroCMS you must purchase a new payment API Key,
which you can purchase at this link:
<br><br>
<a href='https://www.sabro.net/sabrocmsen.htm' target='_blank'>
www.sabro.net/sabrocmsen.htm
</a>
<br><br>
<a href='" . $estescript . "'>[ GO BACK ]</a>
<br><br>
<hr>
<br><br>
La Clave API ingresada:
<br><br>
<b>" . htmlspecialchars($setapi) . "</b>
<br><br>
Caducó el: " . htmlspecialchars($esto) . " (dia/mes/año)
<br><br>
Para seguir usando SabroCMS debe adquirir una nueva Clave API de pago.
<br><br>
<a href='https://www.sabro.net/sabrocms.htm' target='_blank'>
www.sabro.net/sabrocms.htm
</a>
<br><br>
<a href='" . $estescript . "'>[ GO BACK / REGRESAR ]</a>
</div>
</font>";
exit;
}
$line = $setusr . "|" . $setpsw . "|" . $setapi . "|" . $setlg . "|";
$file = fopen("sabrocms.cgi", "w+");
if ($file) {
fwrite($file, $line);
fclose($file);
}
if ($setlg == 'en') {
echo "
<script>
alert('The data entered has been recorded, now you must enter with the username and password confirmed !');
</script>";
} else {
echo "
<script>
alert('Los datos ingresados han sido grabados, ahora debe ingresar con el usuario y password confirmado !');
</script>";
}
echo "
<script>
window.location='" . $estescript . "?logout=confirm';
</script>";
exit;
}
if (!file_exists("sabrocms.cgi")) {
$file = fopen("sabrocms.cgi", "w+");
if ($file) {
fwrite($file, "");
fclose($file);
}
}
$creds = file_get_contents('sabrocms.cgi');
if ($creds === false) {
$creds = '';
}
$partes = explode("|", $creds);
$rusr = isset($partes[0]) ? $partes[0] : '';
$rpsw = isset($partes[1]) ? $partes[1] : '';
$rapi = isset($partes[2]) ? $partes[2] : '';
$rlg  = isset($partes[3]) ? $partes[3] : '';
if (
($rusr == '') ||
($rpsw == '') ||
($rapi == '')
) {
$prekeys =
$rusr . "|" .
$rpsw . "|" .
$rapi . "|" .
$rlg . "|" .
$estescript;
$prekeys = urlencode($prekeys);
$keys = base64_encode($prekeys);
$esto = curle(
$apilink .
"?api=" . urlencode($rapi) .
"&accion=setp&keys=" . urlencode($keys)
);
echo $esto;
exit;
}
$masteruser     = $rusr;
$masterpassword = $rpsw;
$api            = $rapi;
$lg             = $rlg;
ini_set("memory_limit", "32M");
$timeoutenminutos = 120;
$timeoutensegundos = $timeoutenminutos * 60;
session_start();
$loginuser = isset($_POST['loginuser'])
? strtolower(trim($_POST['loginuser']))
: '';
$loginpsw = isset($_POST['loginpsw'])
? strtolower(trim($_POST['loginpsw']))
: '';
if (
($loginuser != '') &&
($loginpsw != '')
) {
if (
($loginuser == strtolower($masteruser)) &&
($loginpsw == strtolower($masterpassword))
) {
session_regenerate_id(true);
$_SESSION['userid'] = "www.sabro.net";
$_SESSION['start_time'] = time();
$_SESSION['folder'] = '';
$_SESSION['lastfolder'] = '/';
}
}
$logeado = "no";
if (isset($_SESSION['userid'])) {
$logeado = "si";
$loginuser = $_SESSION['userid'];
$tiempoactual = time();
$finalfile = "";
}
if ($logeado == "no") {
top();
global $api;
global $apilink;
$codi1 = urlencode(
$estescript . "|" . $lg
);
$prekeys = $codi1;
$keys = base64_encode($prekeys);
$esto = curle(
$apilink .
"?api=" . urlencode($api) .
"&accion=lgn&keys=" . urlencode($keys)
);
echo $esto;
exit;
}
$camdir = isset($_GET['chdr']) ? $_GET['chdr'] : '';
if ($camdir != '') {
if ($camdir == '..') {
$_SESSION['folder'] = "";
} else {
$_SESSION['lastfolder'] = getcwd();
$_SESSION['folder'] = $camdir . "/";
}
}
$zsetup = isset($_GET['setup']) ? $_GET['setup'] : '';
if ($zsetup == "confirm") {
if (!file_exists("sabrocms.cgi")) {
$file = fopen("sabrocms.cgi", "w+");
if ($file) {
fwrite($file, "");
fclose($file);
}
}
$creds = file_get_contents('sabrocms.cgi');
if ($creds === false) {
$creds = '';
}
$partes = explode("|", $creds);
$rusr = isset($partes[0]) ? $partes[0] : '';
$rpsw = isset($partes[1]) ? $partes[1] : '';
$rapi = isset($partes[2]) ? $partes[2] : '';
$rlg  = isset($partes[3]) ? $partes[3] : '';
$prekeys =
$rusr . "|" .
$rpsw . "|" .
$rapi . "|" .
$rlg . "|" .
$estescript;
$prekeys = urlencode($prekeys);
$keys = base64_encode($prekeys);
$esto = curle(
$apilink .
"?api=" . urlencode($api) .
"&accion=setp&keys=" . urlencode($keys)
);
echo $esto;
exit;
}
$zlogout = isset($_GET['logout']) ? $_GET['logout'] : '';
if ($zlogout == "confirm") {
if (
isset($_SESSION['userid']) &&
$_SESSION['userid'] != ""
) {
$loginuser = $_SESSION['userid'];
$finalfile = "";
}
$_SESSION['folder'] = '';
$_SESSION['lastfolder'] = '';
session_unset();
session_destroy();
$logeado = "no";
echo "
<script>
window.location = '" . $estescript . "';
</script>";
exit;
}
if (isset($_SESSION['start_time'])) {
$elapsed_time =
time() - $_SESSION['start_time'];
if ($elapsed_time >= $timeoutensegundos) {
if (
isset($_SESSION['userid']) &&
$_SESSION['userid'] != ""
) {
$loginuser = $_SESSION['userid'];
$finalfile = "";
}
session_unset();
session_destroy();
echo "
<script>
window.location = '" . $estescript . "';
</script>";
exit;
}
}
$_SESSION['start_time'] = time();
$edit   = isset($_GET['edit']) ? $_GET['edit'] : '';
$borrar = isset($_GET['borrar']) ? $_GET['borrar'] : '';
$descargar = isset($_GET['descargar']) ? $_GET['descargar'] : '';
if ($accionpost == 'grabar') {
verifylogin();
$lefile = isset($_POST['lefile']) ? $_POST['lefile'] : '';
$lecont = isset($_POST['lecont']) ? $_POST['lecont'] : '';
top();
if ($lefile != '') {
$file = fopen($lefile, "w+");
if ($file) {
fwrite($file, $lecont . "\n");
fclose($file);
}
}
echo "
<script>
window.location = '" . $estescript . "';
</script>";
exit;
}
if ($accionpost == "crearfile") {
verifylogin();
$contenido = isset($_POST['contenido'])
? $_POST['contenido']
: '';
$filename = isset($_POST['filename'])
? $_POST['filename']
: '';
if ($filename == $estescript) {
echo "
<script>
window.location = '" . $estescript . "';
</script>";
exit;
}
if (
($contenido != '') &&
($filename != '')
) {
if (strlen($filename) > 50) {
echo "
ERROR:<br><br>
The file name (" . htmlspecialchars($filename) . ")
is too long.
<br><br>
(El nombre del archivo es demasiado largo.)
";
exit;
}
$filename =
preg_replace(
"/[^A-Za-z0-9_.-]/",
"_",
$filename
);
$file = fopen(
$_SESSION['folder'] . $filename,
"w+"
);
if ($file) {
fwrite($file, $contenido);
fclose($file);
}
}
echo "
<script>
window.location = '" . $estescript . "';
</script>";
exit;
}
if ($accionpost == "crearfolder") {
verifylogin();
$foldername = isset($_POST['foldername'])
? $_POST['foldername']
: '';
if (
(!is_dir($foldername)) &&
($foldername != '')
) {
if (strlen($foldername) > 50) {
echo "
ERROR:<br><br>
The directory name (" .
htmlspecialchars($foldername) .
") is too long.
<br><br>
(El nombre del directorio es demasiado largo.)
";
exit;
}
$foldername =
preg_replace(
"/[^A-Za-z0-9_.-]/",
"_",
$foldername
);
mkdir(
$_SESSION['folder'] . $foldername
);
}
echo "
<script>
window.location = '" . $estescript . "';
</script>";
exit;
}
if ($accionpost == "clonarfile") {
verifylogin();
$filetoclon = isset($_POST['filetoclon'])
? $_POST['filetoclon']
: '';
$filename = isset($_POST['filename'])
? $_POST['filename']
: '';
if (is_dir($filetoclon)) {
echo "
<script>
window.location = '" . $estescript . "';
</script>";
exit;
}
if (!file_exists($filetoclon)) {
echo "
<script>
window.location = '" . $estescript . "';
</script>";
exit;
}
if ($filename == $estescript) {
echo "
<script>
window.location = '" . $estescript . "';
</script>";
exit;
}
$filename =
preg_replace(
"/[^A-Za-z0-9_.-]/",
"_",
$filename
);
copy(
$filetoclon,
$_SESSION['folder'] . $filename
);
echo "
<script>
window.location = '" . $estescript . "';
</script>";
exit;
}
if ($accionpost == "renombrarfile") {
verifylogin();
$filetorename = isset($_POST['filetoclon'])
? $_POST['filetoclon']
: '';
$filename = isset($_POST['filename'])
? $_POST['filename']
: '';
if (!file_exists($filetorename)) {
echo "
<script>
window.location = '" . $estescript . "';
</script>";
exit;
}
if ($filename == $estescript) {
echo "
<script>
window.location = '" . $estescript . "';
</script>";
exit;
}
$filename =
preg_replace(
"/[^A-Za-z0-9_.-]/",
"_",
$filename
);
rename(
$filetorename,
$_SESSION['folder'] . $filename
);
echo "
<script>
window.location = '" . $estescript . "';
</script>";
exit;
}
if ($accionpost == "cambiarpermisos") {
verifylogin();
$filetomod = isset($_POST['filetoclon'])
? $_POST['filetoclon']
: '';
$permizo = isset($_POST['permizo'])
? $_POST['permizo']
: '';
if (!file_exists($filetomod)) {
echo "
<script>
window.location = '" . $estescript . "';
</script>";
exit;
}
if ($filetomod == $estescript) {
echo "
<script>
window.location = '" . $estescript . "';
</script>";
exit;
}
$filop =
$_SESSION['folder'] . $filetomod;
$permisos_validos = array(
'0400' => 0400,
'0600' => 0600,
'0640' => 0640,
'0644' => 0644,
'0660' => 0660,
'0664' => 0664,
'0666' => 0666,
'0700' => 0700,
'0750' => 0750,
'0755' => 0755,
'0777' => 0777
);
if (isset($permisos_validos[$permizo])) {
chmod(
$filop,
$permisos_validos[$permizo]
);
}
echo "
<script>
window.location = '" . $estescript . "';
</script>";
exit;
}
if ($accionpost == "borrarfiles") {
verifylogin();
$listadu = isset($_POST['listadu'])
? $_POST['listadu']
: '';
$todi = explode(",", $listadu);
foreach ($todi as $x) {
if ($x == '') {
continue;
}
if (is_dir($x)) {
} else {
if (file_exists($x)) {
unlink($x);
}
}
}
echo "
<script>
window.location = '" . $estescript . "';
</script>";
exit;
}
if ($accionpost == "zipearfiles") {
verifylogin();
$listaduzip = isset($_POST['listaduzip'])
? $_POST['listaduzip']
: '';
$todi = explode(",", $listaduzip);
$array = array();
$i = 0;
foreach ($todi as $x) {
if (is_dir($x)) {
continue;
}
if (
file_exists($x) &&
($x != 'backup.zip')
) {
$array[$i] = $x;
$i++;
}
}
$result = create_zip(
$array,
$_SESSION['folder'] . 'backup.zip',
true
);
echo "
<script>
window.location = '" . $estescript . "';
</script>";
exit;
}
if ($accionpost == "upload") {
verifylogin();
subirfile("filetoupload");
echo "
<script>
window.location = '" . $estescript . "';
</script>";
exit;
}
if ($accionpost == "uploadzip") {
verifylogin();
subirzipfile("filetoupload");
echo "
<script>
window.location = '" . $estescript . "';
</script>";
exit;
}
if ($borrar != '') {
verifylogin();
if ($borrar == $estescript) {
echo "
<script>
window.location = '" . $estescript . "';
</script>";
exit;
}
if (file_exists($borrar)) {
if (is_dir($borrar)) {
deldir($borrar);
} else {
unlink($borrar);
}
}
echo "
<script>
window.location = '" . $estescript . "';
</script>";
exit;
}
if ($descargar != '') {
verifylogin();
if ($descargar == $estescript) {
echo "
<script>
window.location = '" . $estescript . "';
</script>";
exit;
}
if (file_exists($descargar)) {
downloadFile($descargar);
}
echo "
<script>
window.location = '" . $estescript . "';
</script>";
exit;
}
if ($edit != '') {
verifylogin();
if (!file_exists($edit)) {
echo "
ERROR:<br><br>
The file " . htmlspecialchars($edit) . "
Does not exist or cannot be read on the server.
<br><br>
<hr><br><br>
(El archivo no existe o no se puede leer en el servidor.)
";
exit;
}
if ($edit == $estescript) {
echo "
<script>
window.location = '" . $estescript . "';
</script>";
exit;
}
top();
echo "Editando el archivo: " .
htmlspecialchars($edit);
$ar = fopen($edit, "r");
$b = 0;
$array = array();
$todo = "";
if ($ar) {
while (!feof($ar)) {
$linea = fgets($ar);
if ($linea !== false) {
$array[$b] = $linea;
$b++;
$todo .= $linea;
}
}
fclose($ar);
}
$todo = htmlspecialchars(
$todo,
ENT_QUOTES,
'UTF-8'
);
echo "
<form method=post action='" . $estescript . "'>
<input type=hidden
name='accionpost'
value='grabar'>
<input type=hidden
name='lefile'
value='" . htmlspecialchars($edit, ENT_QUOTES, 'UTF-8') . "'>
<textarea
name='lecont'
wrap='off'
rows=25
style='width:95%;'>" .
$todo .
"</textarea>
<br>
<input type=submit value='GRABAR'>
<br>
<p align=center>
<a href='" . $estescript . "'>
<b>
<font color=#000000 face=arial size=2>
REGRESAR SIN GRABAR
</font>
</b>
</a>
</form>
</div>
";
exit;
}
$esto = curle(
$apilink .
"?api=" . urlencode($rapi) .
"&accion=chk"
);
if (strpos($esto, '/') !== false) {
echo "
<br><br><br>
<font face=arial size=3 color=#000000>
<div align=center>
<b>
ERROR: La Clave API Pregrabada
<br><br>
Caducó el: " .
htmlspecialchars($esto) .
" (dia/mes/año)
</b>
<br><br><br>
Para seguir usando SabroCMS debe adquirir
una nueva Clave API de pago.
<br><br>
<a href='https://www.sabro.net/sabrocms.htm'
target='_blank'>
www.sabro.net/sabrocms.htm
</a>
<br><br>
<a href='" . $estescript . "?setup=confirm'>
[ INGRESAR NUEVA API ]
</a>
<br><br>
<a href='" . $estescript . "?logout=confirm'>
[ LOGOUT ]
</a>
</div>
</font>";
exit;
}
if ($esto == '0') {
echo "
<br><br><br>
<font face=arial size=3 color=#000000>
<div align=center>
ERROR: La Clave API pregrabada:
<br><br>
<b>" .
htmlspecialchars($rapi) .
"</b>
<br><br>
No es una Clave API Correcta!
<br><br>
Para obtener una Clave API valida, visite:
<br><br>
<a href='https://www.sabro.net/sabrocms.htm'
target='_blank'>
www.sabro.net/sabrocms.htm
</a>
<br><br>
<a href='" . $estescript . "?setup=confirm'>
[ INGRESAR NUEVA API ]
</a>
<br><br>
<a href='" . $estescript . "?logout=confirm'>
[ LOGOUT ]
</a>
</div>
</font>";
exit;
}
top();
global $lg;
if ($lg == 'en') {
echo "
<script>
function confirmp(lifile) {
var msj =
'ALERT: Are you sure you want to delete: '
+ lifile + ' ?';
var agree = confirm(msj);
if (agree)
return true;
else
return false;
}
</script>";
} else {
echo "
<script>
function confirmp(lifile) {
var msj =
'ALERTA: Esta seguro de querer borrar: '
+ lifile + ' ?';
var agree = confirm(msj);
if (agree)
return true;
else
return false;
}
</script>";
}
$archivoslist = leerfiles();
$filesops = '';
$selectfiles = '';
$totalfils = explode(
"|",
$todoslosfiles
);
if (count($totalfils) != 0) {
foreach ($totalfils as $tf) {
if (strpos($tf, "/") !== false) {
$tobo = explode("/", $tf);
$tf =
$tobo[count($tobo) - 1];
}
if ($tf != '') {
$filesops .=
"<option value='" .
htmlspecialchars($tf, ENT_QUOTES, 'UTF-8') .
"'>" .
htmlspecialchars($tf, ENT_QUOTES, 'UTF-8') .
"</option>\n";
}
}
$selectfiles =
"<select name='filetoclon' size='1'>" .
$filesops .
"</select>";
}
echo "
<script>
function cambiar(esto) {
var elemento =
document.getElementById(esto);
if (!elemento) {
return;
}
var vista =
elemento.style.display;
if (vista == 'none')
vista = 'block';
else
vista = 'none';
elemento.style.display = vista;
}
</script>
";
echo "
<table>
<tr>
<td>" .
$archivoslist .
"</td>
</tr>
</table>
";
$pesofile = filesize($estescript);
if (file_exists('error_log')) {
$pesofile += filesize('error_log');
}
$uso =
getdirsize("") -
$pesofile;
$prekeys =
$uso . "|" . $lg;
$keys =
base64_encode($prekeys);
$esto = curle(
$apilink .
"?api=" . urlencode($api) .
"&accion=disk&keys=" . urlencode($keys)
);
echo $esto;
global $api;
global $apilink;
$prekeys =
$estescript .
"|" .
$uso .
"|" .
$lg;
$keys =
base64_encode($prekeys);
$esto = curle(
$apilink .
"?api=" . urlencode($api) .
"&accion=menu1&keys=" . urlencode($keys)
);
echo $esto;
$espaciousado = $uso;
$preespaciolimite =
curle(
$apilink .
"?api=" .
urlencode($api) .
"&accion=lmt"
);
$espaciolimite =
$preespaciolimite * 1;
if ($selectfiles != '') {
$selectfilesvarios =
$selectfiles;
$selectfilesvariosdel =
str_ireplace(
"<select",
"<select id='delifiles' multiple style='width:250px;height:100px;'",
$selectfilesvarios
);
$selectfilesvarioszip =
str_ireplace(
"<select",
"<select id='zipfiles' multiple style='width:250px;height:100px;'",
$selectfilesvarios
);
global $lg;
if (
($espaciousado >= $espaciolimite) &&
($espaciolimite != 0)
) {
if ($lg == 'en') {
$clonyzip = "
<br><br>
<a href=\"#\"
style=\"text-decoration:none\"
onclick=\"cambiar('clonbox'); return false;\">
<b>
<font color=#000000>
Clone a File
</font>
</b>
</a>
<div id=\"clonbox\"
style=\"display:none; overflow:hidden;\">
<br>
<div align=center>
Space limit exceeded,
you must delete some files
to use this option
</div>
</div>
<br><br>
<a href=\"#\"
style=\"text-decoration:none\"
onclick=\"cambiar('zipmanybox'); return false;\">
<b>
<font color=#000000>
Create a ZIP file
</font>
</b>
</a>
<div id=\"zipmanybox\"
style=\"display:none; overflow:hidden;\">
<br>
<div align=center>
Space limit exceeded,
you must delete some files
to use this option
</div>
</div>
";
} else {
$clonyzip = "
<br><br>
<a href=\"#\"
style=\"text-decoration:none\"
onclick=\"cambiar('clonbox'); return false;\">
<b>
<font color=#000000>
Clonar un Archivo
</font>
</b>
</a>
<div id=\"clonbox\"
style=\"display:none; overflow:hidden;\">
<br>
<div align=center>
Limite de espacio superado,
debe eliminar archivos para
poder usar esta opcion
</div>
</div>
<br><br>
<a href=\"#\"
style=\"text-decoration:none\"
onclick=\"cambiar('zipmanybox'); return false;\">
<b>
<font color=#000000>
Hacer ZIP de Varios Archivos
</font>
</b>
</a>
<div id=\"zipmanybox\"
style=\"display:none; overflow:hidden;\">
<br>
<div align=center>
Limite de espacio superado,
debe eliminar archivos para
poder usar esta opcion
</div>
</div>
";
}
} else {
if ($lg == 'en') {
$clonyzip = "
<br><br>
<a href=\"#\"
style=\"text-decoration:none\"
onclick=\"cambiar('clonbox'); return false;\">
<b>
<font color=#000000>
Clone a File
</font>
</b>
</a>
<div id=\"clonbox\"
style=\"display:none; overflow:hidden;\">
<br>
<form method=post
action='" . $estescript . "'>
Copy the file:
" . $selectfiles . "
<input type=hidden
name=accionpost
value=clonarfile>
with this new name:
<input type=\"text\"
name=\"filename\">
<input type=\"submit\"
value=\"Clone\">
</form>
</div>
<br><br>
<a href=\"#\"
style=\"text-decoration:none\"
onclick=\"cambiar('zipmanybox'); return false;\">
<b>
<font color=#000000>
Create a ZIP file
</font>
</b>
</a>
<div id=\"zipmanybox\"
style=\"display:none; overflow:hidden;\">
<br>
<form method=post
action='" . $estescript . "'
name=\"myformazip\">
Select files with [Shift] or [CTRL]
<br>
" . $selectfilesvarioszip . "
<input type=hidden
name=accionpost
value=zipearfiles>
<br>
<input type=hidden
name='listaduzip'
id='listaduzip'
value=''>
<button onclick=\"quezip();return false;\">
Create file backup.zip
</button>
</form>
</div>
";
} else {
$clonyzip = "
<br><br>
<a href=\"#\"
style=\"text-decoration:none\"
onclick=\"cambiar('clonbox'); return false;\">
<b>
<font color=#000000>
Clonar un Archivo
</font>
</b>
</a>
<div id=\"clonbox\"
style=\"display:none; overflow:hidden;\">
<br>
<form method=post
action='" . $estescript . "'>
Copiar el archivo:
" . $selectfiles . "
<input type=hidden
name=accionpost
value=clonarfile>
con este nuevo nombre:
<input type=\"text\"
name=\"filename\">
<input type=\"submit\"
value=\"Clonar\">
</form>
</div>
<br><br>
<a href=\"#\"
style=\"text-decoration:none\"
onclick=\"cambiar('zipmanybox'); return false;\">
<b>
<font color=#000000>
Hacer ZIP de Varios Archivos
</font>
</b>
</a>
<div id=\"zipmanybox\"
style=\"display:none; overflow:hidden;\">
<br>
<form method=post
action='" . $estescript . "'
name=\"myformazip\">
Seleccione archivos con [Shift] o [CTRL]
<br>
" . $selectfilesvarioszip . "
<input type=hidden
name=accionpost
value=zipearfiles>
<br>
<input type=hidden
name='listaduzip'
id='listaduzip'
value=''>
<button onclick=\"quezip();return false;\">
Crear backup.zip
</button>
</form>
</div>
";
}
}
global $lg;
if ($lg == 'en') {
$tresop = "
<br><br>
<a href=\"#\"
style=\"text-decoration:none\"
onclick=\"cambiar('renamebox'); return false;\">
<b>
<font color=#000000>
Rename a File
</font>
</b>
</a>
<div id=\"renamebox\"
style=\"display:none; overflow:hidden;\">
<br>
<form method=post
action='" . $estescript . "'>
Rename the File:
" . $selectfiles . "
<input type=hidden
name=accionpost
value=renombrarfile>
With this new name:
<input type=\"text\"
name=\"filename\">
<input type=\"submit\"
value=\"Rename\">
</form>
</div>
<br><br>
<a href=\"#\"
style=\"text-decoration:none\"
onclick=\"cambiar('changeperm'); return false;\">
<b>
<font color=#000000>
Change File Permission
</font>
</b>
</a>
<div id=\"changeperm\"
style=\"display:none; overflow:hidden;\">
<br>
<form method=post
action='" . $estescript . "'>
Change File Permission:
" . $selectfiles . "
<input type=hidden
name=accionpost
value=cambiarpermisos>
with this permission:
<select name=permizo>
<option selected>0777</option>
<option>0755</option>
<option>0750</option>
<option>0700</option>
<option>0666</option>
<option>0664</option>
<option>0660</option>
<option>0644</option>
<option>0640</option>
<option>0600</option>
<option>0400</option>
</select>
<input type=\"submit\"
value=\"Change\">
</form>
</div>
<br><br>
<a href=\"#\"
style=\"text-decoration:none\"
onclick=\"cambiar('delmanybox'); return false;\">
<b>
<font color=#000000>
Delete Several Files
</font>
</b>
</a>
<div id=\"delmanybox\"
style=\"display:none; overflow:hidden;\">
<br>
<form method=post
action='" . $estescript . "'
name=\"myformadel\">
Select files with [Shift] or [CTRL]
<br>
" . $selectfilesvariosdel . "
<input type=hidden
name=accionpost
value=borrarfiles>
<br>
<input type=hidden
name='listadu'
id='listadu'
value=''>
<button onclick=\"quedel();return false;\">
Delete
</button>
</form>
</div>
";
$funcas = "
function quedel() {
var agree =
confirm(
'Are you sure you want to delete all these files?'
);
if (agree) {
var options =
document.getElementById('delifiles')
.selectedOptions;
var valorez =
Array.from(options)
.map(function(option) {
return option.value;
});
document.getElementById('listadu').value =
valorez.join(',');
document.myformadel.submit();
} else {
return false;
}
}
function quezip() {
var agree =
confirm(
'The selected Files will be compressed in a ZIP file called backup.zip. Do you want to Create the backup.zip file?'
);
if (agree) {
var options =
document.getElementById('zipfiles')
.selectedOptions;
var valorezip =
Array.from(options)
.map(function(option) {
return option.value;
});
document.getElementById('listaduzip').value =
valorezip.join(',');
document.myformazip.submit();
} else {
return false;
}
}
";
} else {
$tresop = "
<br><br>
<a href=\"#\"
style=\"text-decoration:none\"
onclick=\"cambiar('renamebox'); return false;\">
<b>
<font color=#000000>
Renombrar un Archivo
</font>
</b>
</a>
<div id=\"renamebox\"
style=\"display:none; overflow:hidden;\">
<br>
<form method=post
action='" . $estescript . "'>
Renombrar el archivo:
" . $selectfiles . "
<input type=hidden
name=accionpost
value=renombrarfile>
con este nuevo nombre:
<input type=\"text\"
name=\"filename\">
<input type=\"submit\"
value=\"Renombrar\">
</form>
</div>
<br><br>
<a href=\"#\"
style=\"text-decoration:none\"
onclick=\"cambiar('changeperm'); return false;\">
<b>
<font color=#000000>
Cambiar Permisos
</font>
</b>
</a>
<div id=\"changeperm\"
style=\"display:none; overflow:hidden;\">
<br>
<form method=post
action='" . $estescript . "'>
Cambiar Permisos de:
" . $selectfiles . "
<input type=hidden
name=accionpost
value=cambiarpermisos>
Ponerle este permiso:
<select name=permizo>
<option selected>0777</option>
<option>0755</option>
<option>0750</option>
<option>0700</option>
<option>0666</option>
<option>0664</option>
<option>0660</option>
<option>0644</option>
<option>0640</option>
<option>0600</option>
<option>0400</option>
</select>
<input type=\"submit\"
value=\"Cambiar\">
</form>
</div>
<br><br>
<a href=\"#\"
style=\"text-decoration:none\"
onclick=\"cambiar('delmanybox'); return false;\">
<b>
<font color=#000000>
Borrar Varios Archivos
</font>
</b>
</a>
<div id=\"delmanybox\"
style=\"display:none; overflow:hidden;\">
<br>
<form method=post
action='" . $estescript . "'
name=\"myformadel\">
Seleccione archivos con [Shift] o [CTRL]
<br>
" . $selectfilesvariosdel . "
<input type=hidden
name=accionpost
value=borrarfiles>
<br>
<input type=hidden
name='listadu'
id='listadu'
value=''>
<button onclick=\"quedel();return false;\">
Borrar
</button>
</form>
</div>
";
$funcas = "
function quedel() {
var agree =
confirm(
'Esta seguro de querer borrar todos estos archivos?'
);
if (agree) {
var options =
document.getElementById('delifiles')
.selectedOptions;
var valorez =
Array.from(options)
.map(function(option) {
return option.value;
});
document.getElementById('listadu').value =
valorez.join(',');
document.myformadel.submit();
} else {
return false;
}
}
function quezip() {
var agree =
confirm(
'Los archivos seleccionados seran comprimidos en backup.zip. Desea crear el archivo backup.zip?'
);
if (agree) {
var options =
document.getElementById('zipfiles')
.selectedOptions;
var valorezip =
Array.from(options)
.map(function(option) {
return option.value;
});
document.getElementById('listaduzip').value =
valorezip.join(',');
document.myformazip.submit();
} else {
return false;
}
}
";
}
$data2 = "
<script>
" . $funcas . "
</script>
" . $clonyzip . "
" . $tresop . "
";
echo $data2;
}
echo "
<br><br><br><br><br><br><br>
";
echo "</div>";
function subirfile(
$filename,
$tamanomaximo = 10485760,
$directoriodestino = ''
) {
global $estescript;
$directoriodestino =
isset($_SESSION['folder'])
? $_SESSION['folder']
: '';
if (
!isset($_FILES['filetoupload']) ||
!isset($_FILES['filetoupload']['name'])
) {
return;
}
$nombredelarchivo =
basename(
$_FILES['filetoupload']['name']
);
if (
trim($nombredelarchivo) !=
trim($estescript)
) {
$tamano =
isset($_FILES['filetoupload']['size'])
? $_FILES['filetoupload']['size']
: 0;
$archivotemporal =
isset($_FILES['filetoupload']['tmp_name'])
? $_FILES['filetoupload']['tmp_name']
: '';
if ($nombredelarchivo != '') {
$archivodestino =
$directoriodestino .
$nombredelarchivo;
if ($tamano > $tamanomaximo) {
echo "
ERROR: El archivo (" .
htmlspecialchars($nombredelarchivo) .
") supera los 10 Megabytes.
<br><br>
No se permite subir archivos superiores
a ese tamaño.
";
exit;
}
if (
move_uploaded_file(
$archivotemporal,
$archivodestino
)
) {
} else {
echo "
Error:
El Archivo no fue subido
";
exit;
}
}
}
}
function subirzipfile(
$filename,
$tamanomaximo = 20971520,
$directoriodestino = ''
) {
$directoriodestino =
isset($_SESSION['folder'])
? $_SESSION['folder']
: '';
if (
!isset($_FILES['filetoupload']) ||
!isset($_FILES['filetoupload']['name'])
) {
return;
}
$nombredelarchivo =
basename(
$_FILES['filetoupload']['name']
);
$tamano =
isset($_FILES['filetoupload']['size'])
? $_FILES['filetoupload']['size']
: 0;
$archivotemporal =
isset($_FILES['filetoupload']['tmp_name'])
? $_FILES['filetoupload']['tmp_name']
: '';
$extension =
strtolower(
pathinfo(
$nombredelarchivo,
PATHINFO_EXTENSION
)
);
if (
($nombredelarchivo != '') &&
($extension == "zip")
) {
$archivodestino =
$directoriodestino . "zip.zip";
if ($tamano > $tamanomaximo) {
echo "
ERROR: El archivo (" .
htmlspecialchars($nombredelarchivo) .
") supera los 20 Megabytes.
<br><br>
No se permite subir archivos superiores
a ese tamaño.
";
exit;
}
if (
move_uploaded_file(
$archivotemporal,
$archivodestino
)
) {
if (class_exists('ZipArchive')) {
$zip = new ZipArchive();
if (
$zip->open($archivodestino) === true
) {
for (
$i = 0;
$i < $zip->numFiles;
$i++
) {
$nombre =
$zip->getNameIndex($i);
$nombre =
str_replace(
"\\",
"/",
$nombre
);
if (
strpos($nombre, '../') !== false ||
strpos($nombre, '..\\') !== false ||
substr($nombre, 0, 1) == '/'
) {
continue;
}
if (
substr($nombre, -1) == '/'
) {
$dir =
$directoriodestino .
$nombre;
if (!is_dir($dir)) {
mkdir(
$dir,
0755,
true
);
}
continue;
}
$destino =
$directoriodestino .
$nombre;
$dirpadre =
dirname($destino);
if (!is_dir($dirpadre)) {
mkdir(
$dirpadre,
0755,
true
);
}
$contenido =
$zip->getFromIndex($i);
if ($contenido !== false) {
file_put_contents(
$destino,
$contenido
);
}
}
$zip->close();
}
} else {
if (function_exists('zip_open')) {
$zip =
zip_open($archivodestino);
if ($zip) {
while (
$zip_entry =
zip_read($zip)
) {
$nombre =
zip_entry_name(
$zip_entry
);
$nombre =
str_replace(
"\\",
"/",
$nombre
);
if (
strpos($nombre, '../') !== false ||
strpos($nombre, '..\\') !== false ||
substr($nombre, 0, 1) == '/'
) {
continue;
}
$destino =
$directoriodestino .
$nombre;
if (
substr($nombre, -1) == '/'
) {
if (!is_dir($destino)) {
mkdir(
$destino,
0755,
true
);
}
continue;
}
$dirpadre =
dirname($destino);
if (!is_dir($dirpadre)) {
mkdir(
$dirpadre,
0755,
true
);
}
$fp =
fopen(
$destino,
"w"
);
if (
$fp &&
zip_entry_open(
$zip,
$zip_entry,
"r"
)
) {
$buf =
zip_entry_read(
$zip_entry,
zip_entry_filesize(
$zip_entry
)
);
fwrite(
$fp,
$buf
);
zip_entry_close(
$zip_entry
);
fclose($fp);
}
}
zip_close($zip);
}
}
}
if (file_exists($archivodestino)) {
unlink($archivodestino);
}
} else {
echo "
Error:
El Archivo no fue subido
";
exit;
}
} else {
echo "
ERROR:
El archivo debe ser ZIP.
";
exit;
}
}
function leerfiles() {
global $estescript;
global $api;
global $apilink;
global $todoslosfiles;
$list = '';
$todoslosfiles = '';
if (
isset($_SESSION['folder']) &&
$_SESSION['folder'] != ''
) {
echo "
<div align=center>
<div style='max-width:900px;'>
<img
src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAA+gAAAABCAYAAABNAIQzAAAAG0lEQVR42u3BMQEAAADCoPVPbQwfoAAAAIC7AQ+hAAEipZISAAAAAElFTkSuQmCC'
width=100%
height=1>
<table bgcolor=#f3f3f3
width=100%>
<tr>
<td>
<a href='" .
$estescript .
"?chdr=..'>
<font face=arial size=2>
<b>\</b>
</font>
</a>
</td>
</tr>
</table>
</div>
</div>
<br>
";
}
$folder =
isset($_SESSION['folder'])
? $_SESSION['folder']
: '';
foreach (
glob($folder . "*")
as $filename
) {
if (
($filename != $estescript) &&
($filename != "error_log") &&
($filename != "sabrocms.cgi")
) {
$todoslosfiles .=
$filename . "|";
$archivoseditables =
"js,htm,txt,css,php,html,shtml,xml,perl,cgi,pt";
$linea =
darformato(
$filename,
$archivoseditables
);
$list .= $linea;
}
}
return $list;
}

function darformato($filename, $archivoseditables) {
    global $lg;
    global $estescript;
    $archi = $filename;
    $esdirectorio = is_dir($filename);
    if (!$esdirectorio && is_file($filename)) {
        $bytes = @filesize($filename);
        if ($bytes === false) {
            $bytes = 0;
        }

        $filesizo = $bytes / 1024;
        $filesizo = round($filesizo, 2);

        if (($filesizo == 0) && ($bytes > 0)) {
            $filesizo = 0.01;
        }

    } else {

        $filesizo = 0;

    }
    $editable = false;

    if (!$esdirectorio) {

        $extension = strtolower(
            pathinfo($filename, PATHINFO_EXTENSION)
        );

        if ($extension != '') {

            $tipos = array(
                'js',
                'htm',
                'txt',
                'css',
                'php',
                'html',
                'shtml',
                'xml',
                'perl',
                'cgi',
                'pt'
            );

            if (in_array($extension, $tipos, true)) {
                $editable = true;
            }
        }
    }
    $fileshow = basename($filename);
    $fileshow_html = htmlspecialchars(
        $fileshow,
        ENT_QUOTES,
        'UTF-8'
    );

    $filename_html = htmlspecialchars(
        $filename,
        ENT_QUOTES,
        'UTF-8'
    );

    if ($esdirectorio) {

        $nombre_directorio = rtrim($filename, '/');

        $nombre_html = htmlspecialchars(
            basename($nombre_directorio),
            ENT_QUOTES,
            'UTF-8'
        );

        return "
        <div align='center'>
        <div style='max-width:900px;'>
        <table bgcolor='#f3f3f3' width='100%'>
        <tr>

        <td width='55%'>
        <font face='arial' size='2' color='#000000'>
        <b>
        {$nombre_html}/
        </b>
        </font>
        </td>

        <td width='15%'>
        <font face='arial' size='1' color='#000000'>
        Directorio
        </font>
        </td>

        <td width='20%'>
        <a href='" .
        htmlspecialchars(
            $estescript . "?chdr=" .
            urlencode($nombre_directorio),
            ENT_QUOTES,
            'UTF-8'
        ) .
        "'>
        <div align='center'>
        <font face='arial' size='2'>
        [ENTRAR]
        </font>
        </div>
        </a>
        </td>

        <td width='5%'>
        </td>

        <td width='5%'>
        <a href='" .
        htmlspecialchars(
            $estescript . "?borrar=" .
            urlencode($nombre_directorio),
            ENT_QUOTES,
            'UTF-8'
        ) .
        "' onclick=\"return confirmp('" .
        htmlspecialchars(
            $nombre_directorio,
            ENT_QUOTES,
            'UTF-8'
        ) .
        "');\">

        <div align='center'>
        <font face='arial' size='2' color='red'>
        [BORRAR]
        </font>
        </div>

        </a>
        </td>

        </tr>
        </table>
        </div>
        </div>
<!--spacer2--><table width=100% height=6 border=0 cellspacing=0 cellpadding=0><tr><td bgcolor=#ffffff></td></tr></table>
        ";

    }

    $linkeditar = '';

    if ($editable) {

        $linkeditar =
            "<a href='" .
            htmlspecialchars(
                $estescript .
                "?edit=" .
                urlencode($archi),
                ENT_QUOTES,
                'UTF-8'
            ) .
            "'>";

        if ($lg == 'en') {
            $linkeditar .= "[EDIT]";
        } else {
            $linkeditar .= "[EDITAR]";
        }

        $linkeditar .= "</a>";
    }

    /*
     * Texto de botones
     */
    if ($lg == 'en') {

        $viewf = 'View File';
        $delf  = 'DELETE';

    } else {

        $viewf = 'Ver Archivo';
        $delf  = 'BORRAR';
    }

    return "
    <div align='center'>
    <div style='max-width:900px;'>

    <table bgcolor='#f3f3f3' width='100%'>

    <tr>

    <td width='55%'>
    <font face='arial' size='2' color='#000000'>
    {$fileshow_html}
    </font>
    </td>

    <td width='15%'>
    <font face='arial' size='1' color='#000000'>
    {$filesizo} Kb
    </font>
    </td>

    <td width='20%'>
    <a target='_blank'
       href='" .
       htmlspecialchars(
           $filename,
           ENT_QUOTES,
           'UTF-8'
       ) .
       "'>

    <div align='center'>
    <font face='arial' size='2'>
    [{$viewf}]
    </font>
    </div>

    </a>
    </td>

    <td width='5%'>
    <div align='center'>
    <font face='arial' size='2'>
    {$linkeditar}
    </font>
    </div>
    </td>

    <td width='5%'>

    <a href='" .
    htmlspecialchars(
        $estescript .
        "?borrar=" .
        urlencode($filename),
        ENT_QUOTES,
        'UTF-8'
    ) .
    "' onclick=\"return confirmp('" .
    htmlspecialchars(
        $filename,
        ENT_QUOTES,
        'UTF-8'
    ) .
    "');\">

    <div align='center'>
    <font face='arial'
          size='2'
          color='red'>

    [{$delf}]

    </font>
    </div>

    </a>

    </td>

    </tr>

    </table>

    </div>
    </div>
<!--spacer1--><table width=100% height=6 border=0 cellspacing=0 cellpadding=0><tr><td bgcolor=#ffffff></td></tr></table>
    ";
}

function verifylogin() {
global $logeado;
global $estescript;
if ($logeado == "no") {
echo "
<script>
window.location = '" .
$estescript .
"';
</script>";
exit;
}
}
function top() {
global $logeado;
global $timeoutensegundos;
global $estescript;
global $api;
global $apilink;
global $edit;
if (!isset($edit) || $edit === null) {
    $edit = '';
}
$logout = '';
if ($logeado == "si") {
$logout = "
<div align=center>
<table width=90%>
<tr>
<td>
<p align=right>
<b>
<font
face=arial
color=red
size=3>
<a href=" .
$estescript .
"?logout=confirm>
LOGOUT
</a>
<br>
<a href=" .
$estescript .
"?setup=confirm>
SETUP
</a>
</font>
<b>
</td>
</tr>
</table>
</div>
";
}
echo $logout;
echo '
<meta http-equiv="Content-Type"
content="text/html; charset=UTF-8">
<!-- SabroCMS powered by www.sabro.net -->
<!DOCTYPE html>
<meta name="viewport"
content="width=device-width,
initial-scale=1.0,
maximum-scale=1.0,
user-scalable=no">
';
$codi1 = urlencode((string)$edit);
$prekeys =
$codi1;
$keys =
base64_encode($prekeys);
$esto = curle(
$apilink .
"?api=" .
urlencode($api) .
"&accion=tnyct&keys=" .
urlencode($keys)
);
echo $esto;
$timek =
$timeoutensegundos * 1000;
if ($logeado == "si") {
echo "
<script>
setTimeout(
function() {
window.location='" .
$estescript .
"';
},
" .
$timek .
"
);
</script>
";
}
}
function downloadFile($fileUrl) {
if (
substr($fileUrl, 0, 4) == 'http'
) {
$headers =
@get_headers(
$fileUrl,
1
);
if (
$headers !== false
) {
$headers =
array_change_key_case(
$headers,
CASE_LOWER
);
if (
isset($headers['content-length'])
) {
$fileSize =
$headers['content-length'];
} else {
$fileSize = 0;
}
} else {
$fileSize = 0;
}
} else {
$fileSize =
@filesize($fileUrl);
}
$ctype =
"application/octet-stream";
header("Pragma: public");
header("Expires: 0");
header(
"Cache-Control: must-revalidate, post-check=0, pre-check=0"
);
header(
"Cache-Control: private",
false
);
header(
"Content-Type: " . $ctype
);
header(
"Content-Disposition: attachment; filename=\"" .
basename($fileUrl) .
"\";"
);
header(
"Content-Transfer-Encoding: binary"
);
if ($fileSize !== false) {
header(
"Content-Length: " .
$fileSize
);
}
readfile($fileUrl);
exit;
}
function curle($url) {
$xd = '';
if (
isset($_SERVER['HTTP_HOST']) &&
$_SERVER['HTTP_HOST'] != ''
) {
$xd =
strtolower(
trim(
$_SERVER['HTTP_HOST']
)
);
} elseif (
isset($_SERVER['SERVER_NAME']) &&
$_SERVER['SERVER_NAME'] != ''
) {
$xd =
strtolower(
trim(
$_SERVER['SERVER_NAME']
)
);
}
$xd =
preg_replace(
'/:\d+$/',
'',
$xd
);
if (
substr($xd, 0, 4) === 'www.'
) {
$xd =
substr(
$xd,
4
);
}
if ($xd == '') {
$tmp =
isset($_SERVER['SERVER_ADDR'])
? $_SERVER['SERVER_ADDR']
: '';
$xd = $tmp;
}
$referer =
"https://" .
$xd .
"/";
$ch =
curl_init();
curl_setopt_array(
$ch,
array(
CURLOPT_URL =>
$url,
CURLOPT_HEADER =>
false,
CURLOPT_RETURNTRANSFER =>
true,
CURLOPT_FOLLOWLOCATION =>
true,
CURLOPT_MAXREDIRS =>
5,
CURLOPT_CONNECTTIMEOUT =>
10,
CURLOPT_TIMEOUT =>
30,
CURLOPT_USERAGENT =>
'SabroCMS/1.0',
CURLOPT_SSL_VERIFYPEER =>
true,
CURLOPT_SSL_VERIFYHOST =>
2,
CURLOPT_REFERER =>
$referer,
CURLOPT_HTTPHEADER =>
array(
'Accept: */*',
'Cache-Control: no-cache'
)
)
);
$data =
curl_exec($ch);
if (
$data === false
) {
$error =
curl_error($ch);
$errno =
curl_errno($ch);
curl_close($ch);
return
"CURL_ERROR[" .
$errno .
"]: " .
$error;
}
$httpcode =
curl_getinfo(
$ch,
CURLINFO_HTTP_CODE
);
curl_close($ch);
$data =
trim(
$data,
" \t\n\r\0\x0B\xEF\xBB\xBF"
);
return $data;
}
function deldir($dir) {
if (!is_dir($dir)) {
return;
}
$it =
new RecursiveDirectoryIterator(
$dir,
FilesystemIterator::SKIP_DOTS
);
$it =
new RecursiveIteratorIterator(
$it,
RecursiveIteratorIterator::CHILD_FIRST
);
foreach ($it as $file) {
if ($file->isDir()) {
rmdir(
$file->getPathname()
);
} else {
unlink(
$file->getPathname()
);
}
}
rmdir($dir);
}
function create_zip(
$files = array(),
$destination = '',
$overwrite = false
) {
if (
file_exists($destination) &&
!$overwrite
) {
return false;
}
$valid_files = array();
if (is_array($files)) {
foreach ($files as $file) {
if (
file_exists($file) &&
!is_dir($file)
) {
$valid_files[] =
$file;
}
}
}
if (count($valid_files)) {
if (!class_exists('ZipArchive')) {
return false;
}
$zip =
new ZipArchive();
$modo =
$overwrite
? ZIPARCHIVE::OVERWRITE
: ZIPARCHIVE::CREATE;
if (
$zip->open(
$destination,
$modo
) !== true
) {
return false;
}
foreach ($valid_files as $file) {
$zip->addFile(
$file,
basename($file)
);
}
$zip->close();
return file_exists(
$destination
);
}
return false;
}
function getdirsize($path) {
$bytestotal = 0;
$path =
realpath($path);
if (
$path !== false &&
$path != '' &&
file_exists($path)
) {
foreach (
new RecursiveIteratorIterator(
new RecursiveDirectoryIterator(
$path,
FilesystemIterator::SKIP_DOTS
)
)
as $object
) {
$bytestotal +=
$object->getSize();
}
}
return $bytestotal;
}
?>